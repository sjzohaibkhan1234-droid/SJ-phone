package com.voicemaster.ai

import com.voicemaster.data.SecureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.channels.awaitClose
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

sealed interface AiEvent {
    data class Text(val delta: String) : AiEvent
    data class ToolCall(val id: String, val input: JSONObject) : AiEvent
    data class Done(val stopReason: String?) : AiEvent
    data class Error(val msg: String) : AiEvent
}

@Singleton
class ClaudeClient @Inject constructor(private val store: SecureStore) {
    private val http by lazy {
        OkHttpClient.Builder().readTimeout(0, TimeUnit.SECONDS).connectTimeout(10, TimeUnit.SECONDS).build()
    }
    companion object { const val MODEL = "claude-sonnet-5-5" }

    /** Streams one assistant turn. `messages` is the full conversation (Anthropic format). */
    fun stream(messages: JSONArray): Flow<AiEvent> = callbackFlow {
        val body = JSONObject()
            .put("model", MODEL).put("max_tokens", 1024).put("stream", true)
            .put("system", Prompts.SYSTEM).put("tools", Prompts.tools())
            .put("messages", messages).toString()
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", store.apiKey).header("anthropic-version", "2023-06-01")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        val call = http.newCall(req)
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) { trySend(AiEvent.Error("HTTP ${resp.code}")); close(); return@use }
                val src = resp.body!!.source()
                var toolId = ""; val json = StringBuilder(); var inTool = false; var stop: String? = null
                while (!src.exhausted()) {
                    val line = src.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val e = JSONObject(line.removePrefix("data:").trim())
                    when (e.optString("type")) {
                        "content_block_start" -> e.getJSONObject("content_block").let {
                            if (it.optString("type") == "tool_use") { inTool = true; toolId = it.getString("id"); json.clear() }
                        }
                        "content_block_delta" -> e.getJSONObject("delta").let {
                            when (it.optString("type")) {
                                "text_delta" -> trySend(AiEvent.Text(it.getString("text")))
                                "input_json_delta" -> json.append(it.getString("partial_json"))
                            }
                        }
                        "content_block_stop" -> if (inTool) {
                            inTool = false
                            val s = json.toString().ifBlank { "{}" }
                            trySend(AiEvent.ToolCall(toolId, JSONObject(s)))
                        }
                        "message_delta" -> stop = e.optJSONObject("delta")?.optString("stop_reason")
                    }
                }
                trySend(AiEvent.Done(stop))
            }
        } catch (t: Throwable) { trySend(AiEvent.Error(t.message ?: "network")) }
        close()
        awaitClose { call.cancel() }
    }.flowOn(Dispatchers.IO)
}
