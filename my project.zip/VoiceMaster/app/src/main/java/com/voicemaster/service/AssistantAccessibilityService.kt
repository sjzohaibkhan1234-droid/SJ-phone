package com.voicemaster.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AssistantAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: AssistantAccessibilityService? = null
        /** Never read or operate screens of these apps (banking / wallets / password managers). */
        private val BLOCKED = listOf("bank", "paytm", "phonepe", "gpay", "google.android.apps.nbu.paisa",
            "wallet", "bhim", "upi", "lastpass", "bitwarden", "1password", "keepass")
    }
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(i: android.content.Intent?): Boolean { instance = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun sensitive(root: AccessibilityNodeInfo?): Boolean {
        val pkg = root?.packageName?.toString()?.lowercase() ?: return false
        if (BLOCKED.any { pkg.contains(it) }) return true
        return hasPassword(root)
    }
    private fun hasPassword(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        if (n.isPassword) return true
        for (i in 0 until n.childCount) if (hasPassword(n.getChild(i))) return true
        return false
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "screen not available"
        if (sensitive(root)) return "BLOCKED: sensitive screen (banking/password). Refuse to operate."
        val sb = StringBuilder("app: ${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || sb.length > 3500) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) sb.append(if (n.isClickable) "[btn] " else "").append(t.take(80)).append('\n')
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0); return sb.toString()
    }

    fun tapText(text: String): String {
        val root = rootInActiveWindow ?: return "screen not available"
        if (sensitive(root)) return "BLOCKED: sensitive screen"
        val node = root.findAccessibilityNodeInfosByText(text).firstOrNull() ?: return "text not found"
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        return if ((n ?: node).performAction(AccessibilityNodeInfo.ACTION_CLICK)) "tapped $text" else "tap failed"
    }

    fun tap(x: Float, y: Float): String {
        if (sensitive(rootInActiveWindow)) return "BLOCKED: sensitive screen"
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
        return "tapped"
    }

    fun scroll(dir: String): String {
        val m = resources.displayMetrics; val w = m.widthPixels.toFloat(); val h = m.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "down" -> { p.moveTo(w / 2, h * 0.75f); p.lineTo(w / 2, h * 0.25f) }
            "up" -> { p.moveTo(w / 2, h * 0.25f); p.lineTo(w / 2, h * 0.75f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            else -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
        }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
        return "scrolled $dir"
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "screen not available"
        if (sensitive(root)) return "BLOCKED: sensitive screen"
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "no focused text field"
        val args = android.os.Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "typed" else "type failed"
    }

    fun press(key: String): String {
        val ok = when (key) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)      // API 28
            "screenshot" -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) // API 28
            else -> false
        }
        return if (ok) "done" else "failed"
    }
}
