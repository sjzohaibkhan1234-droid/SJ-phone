package com.voicemaster.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.voicemaster.service.AssistantService
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF7C9CFF), background = Color(0xFF0B0D12), surface = Color(0xFF151823))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Root(vm) }
            }
        }
        if (intent.getBooleanExtra("autolisten", false)) vm.startListening()
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); if (i.getBooleanExtra("autolisten", false)) vm.startListening() }
}

@Composable
fun Root(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(containerColor = Color.Transparent, bottomBar = {
        NavigationBar {
            NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Mic, null) }, label = { Text("Home") })
            NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
        }
    }) { pad -> Box(Modifier.padding(pad)) { if (tab == 0) Home(vm) else SettingsScreen(vm) } }
}

@Composable
fun Home(vm: MainViewModel) {
    val s by vm.ui.collectAsStateWithLifecycle()
    val hist by vm.history.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) vm.startListening() }
    fun tapMic() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == 0) vm.startListening()
        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp))
        if (s.listening) Text("● Mic is listening", color = Color(0xFFFF5252)) // required mic indicator
        Spacer(Modifier.height(12.dp))
        Waveform(s.level, s.listening)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.size(96.dp).clip(CircleShape).background(if (s.listening) Color(0xFFFF5252) else MaterialTheme.colorScheme.primary)
            .clickable { tapMic() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Mic, "Speak", Modifier.size(44.dp), tint = Color.Black)
        }
        Spacer(Modifier.height(16.dp))
        Text(s.transcript.ifBlank { "Tap the mic and speak" }, style = MaterialTheme.typography.titleMedium)
        if (s.thinking) LinearProgressIndicator(Modifier.padding(top = 8.dp).fillMaxWidth(0.5f))
        if (s.reply.isNotBlank()) Text(s.reply, Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.primary)
        if (s.lastResult.isNotBlank()) Text("Result: ${s.lastResult}", Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { vm.kill() }) { Icon(Icons.Default.Stop, null); Spacer(Modifier.width(6.dp)); Text("STOP (kill switch)") }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(hist, key = { it.id }) {
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) {
                    Text(it.command, style = MaterialTheme.typography.bodyMedium)
                    Text(it.result, style = MaterialTheme.typography.bodySmall, color = Color.Gray) } }
            }
        }
    }
}

@Composable
fun Waveform(level: Float, active: Boolean) {
    val t by rememberInfiniteTransition(label = "w").animateFloat(0f, 6.28f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "p")
    Canvas(Modifier.fillMaxWidth().height(64.dp)) {
        val n = 28; val gap = size.width / n
        for (i in 0 until n) {
            val amp = if (active) (0.15f + level * 0.85f) * (0.5f + 0.5f * kotlin.math.sin(t + i * 0.5f)) else 0.06f
            val h = size.height * amp.coerceIn(0.05f, 1f)
            drawLine(Color(0xFF7C9CFF), Offset(i * gap + gap / 2, size.height / 2 - h / 2), Offset(i * gap + gap / 2, size.height / 2 + h / 2), strokeWidth = gap * 0.5f)
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(vm.store.apiKey) }
    var lang by remember { mutableStateOf(vm.store.sttLang) }
    fun open(a: String, uri: String? = null) = ctx.startActivity(Intent(a).apply { uri?.let { data = Uri.parse(it) } })
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Settings & permissions", style = MaterialTheme.typography.headlineSmall) }
        item {
            OutlinedTextField(key, { key = it; vm.store.apiKey = it }, label = { Text("Claude API key") },
                visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        item {
            Text("Speech language")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("hi-IN" to "Hindi / Hinglish", "en-IN" to "English", "ur-PK" to "Urdu").forEach { (c, n) ->
                    FilterChip(lang == c, { lang = c; vm.store.sttLang = c }, { Text(n) })
                }
            }
        }
        item { Text("Grant these once (guided setup)", style = MaterialTheme.typography.titleMedium) }
        item { PermBtn("1. Mic, contacts, phone, SMS, notifications") {
            perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CAMERA)) } }
        item { PermBtn("2. Display over other apps (floating mic)") { open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, "package:${ctx.packageName}") } }
        item { PermBtn("3. Accessibility (tap, scroll, type, read screen)") { open(Settings.ACTION_ACCESSIBILITY_SETTINGS) } }
        item { PermBtn("4. Notification access (read notifications)") { open(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) } }
        item { PermBtn("5. Modify system settings (brightness)") { open(Settings.ACTION_MANAGE_WRITE_SETTINGS, "package:${ctx.packageName}") } }
        item { PermBtn("6. Battery optimization exemption") {
            if (!(ctx.getSystemService(PowerManager::class.java)).isIgnoringBatteryOptimizations(ctx.packageName))
                open(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, "package:${ctx.packageName}") } }
        item { PermBtn("Start floating mic service") { ContextCompat.startForegroundService(ctx, Intent(ctx, AssistantService::class.java)) } }
        item { PermBtn("Stop floating mic service") { ctx.stopService(Intent(ctx, AssistantService::class.java)) } }
        item { TextButton({ vm.clearHistory() }) { Text("Clear history") } }
    }
}

@Composable private fun PermBtn(t: String, onClick: () -> Unit) =
    Button(onClick, Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text(t) }
