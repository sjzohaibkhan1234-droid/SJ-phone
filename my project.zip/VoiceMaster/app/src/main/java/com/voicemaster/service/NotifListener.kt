package com.voicemaster.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    companion object {
        @Volatile private var inst: NotifListener? = null
        fun recent(): String {
            val l = inst ?: return ""
            return l.activeNotifications.take(8).joinToString("\n") {
                val e = it.notification.extras
                "${it.packageName}: ${e.getCharSequence(Notification.EXTRA_TITLE) ?: ""} - ${e.getCharSequence(Notification.EXTRA_TEXT) ?: ""}"
            }
        }
    }
    override fun onListenerConnected() { inst = this }
    override fun onListenerDisconnected() { inst = null }
    override fun onNotificationPosted(sbn: StatusBarNotification?) {}
}
