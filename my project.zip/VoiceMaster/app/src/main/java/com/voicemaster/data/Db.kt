package com.voicemaster.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class HistoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val command: String, val result: String, val time: Long = System.currentTimeMillis()
)

@Dao interface HistoryDao {
    @Query("SELECT * FROM HistoryItem ORDER BY time DESC LIMIT 50") fun recent(): Flow<List<HistoryItem>>
    @Insert suspend fun add(i: HistoryItem)
    @Query("DELETE FROM HistoryItem") suspend fun clear()
}

@Database(entities = [HistoryItem::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun history(): HistoryDao
    companion object {
        fun build(c: Context) = Room.databaseBuilder(c, AppDb::class.java, "vm.db").build()
    }
}
