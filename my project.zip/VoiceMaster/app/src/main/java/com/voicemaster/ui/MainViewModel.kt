package com.voicemaster.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.voicemaster.action.ActionExecutor
import com.voicemaster.action.LocalMatcher
import com.voicemaster.ai.AiEvent
import com.voicemaster.ai.ClaudeClient
import com.voicemaster.data.HistoryDao
import com.voicemaster.data.HistoryItem
import com.voicemaster.data.SecureStore
import com.voicemaster.voice.VoiceEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject

data class UiState(
    val listening: Boolean = false, val thinking: Boolean = false,
    val transcript: String = "", val reply: String = "", val lastResult: String = "", val level: Float = 0f
)

@HiltViewModel
class MainViewModel @Inject constructor(
    app: Application, private val voice: VoiceEngine, private val ai: ClaudeClient,
    private val exec: ActionExecutor, private val dao: HistoryDao, val store: SecureStore
) : AndroidViewModel(app) {

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui
    val history = dao.recent().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val convo = JSONArray()           // running Anthropic-format conversation
    private var pendingConfirm: JSONObject? = null
    private var job: Job? = null

    init { viewModelScope.launch(Dispatchers.Default) { voice.warmUp() } } // off the critical path

    fun startListening() {
        job?.cancel(); _ui.update { it.copy(listening = true, transcript = "", reply = "") }
        voice.listen(store.sttLang,
            onPartial = { t -> _ui.update { it.copy(transcript = t) } },
            onFinal = { t -> _ui.update { it.copy(listening = false, transcript = t) }; handle(t) },
            onError = { _ui.update { it.copy(listening = false) } },
            onRms = { v -> _ui.update { it.copy(level = ((v + 2f) / 12f).coerceIn(0f, 1f)) } })
    }

    /** One-tap kill switch: stop mic, speech, and any running action chain. */
    fun kill() { job?.cancel(); voice.stopListening(); voice.stopSpeaking(); pendingConfirm = null; _ui.value = UiState(lastResult = "روک دیا گیا") }

    private fun handle(text: String) {
        // 1) answer to a pending voice confirmation
        pendingConfirm?.let { a ->
            pendingConfirm = null
            val yes = Regex("yes|haan|han|ha\\b|ok|okay|kar do|bhej do|हाँ|हां|कर दो|भेज दो|جی|ہاں", RegexOption.IGNORE_CASE).containsMatchIn(text)
            job = viewModelScope.launch {
                if (yes) { val r = exec.execute(a); done(text, r, "ہو گیا") } else done(text, "cancelled", "منسوخ کر دیا")
            }; return
        }
        // 2) instant local commands
        LocalMatcher.match(text)?.let { m ->
            job = viewModelScope.launch { val r = exec.execute(m.args); voice.speak(m.reply, true); done(text, r, m.reply) }
            return
        }
        // 3) Claude
        if (store.apiKey.isBlank()) { say("پہلے سیٹنگز میں API کی ڈالیں"); return }
        _ui.update { it.copy(thinking = true) }
        convo.put(JSONObject().put("role", "user").put("content", text))
        job = viewModelScope.launch { runAiTurn(text) }
    }

    private suspend fun runAiTurn(userText: String, depth: Int = 0) {
        val buf = StringBuilder(); val spoken = StringBuilder(); val assistant = JSONArray(); val results = JSONArray()
        var confirmNeeded: JSONObject? = null
        ai.stream(convo).collect { e ->
            when (e) {
                is AiEvent.Text -> {
                    buf.append(e.delta); spoken.append(e.delta)
                    _ui.update { it.copy(reply = buf.toString()) }
                    // speak sentence by sentence while streaming
                    val m = Regex("^(.*?[.!?۔؟\n])").find(spoken)
                    if (m != null) { voice.speak(m.value.trim()); spoken.delete(0, m.value.length) }
                }
                is AiEvent.ToolCall -> {
                    val a = e.input
                    assistant.put(JSONObject().put("type", "tool_use").put("id", e.id).put("name", "phone_action").put("input", a))
                    val r = if (exec.needsConfirm(a.optString("action"))) {
                        confirmNeeded = a; "awaiting user confirmation"
                    } else exec.execute(a)
                    results.put(JSONObject().put("type", "tool_result").put("tool_use_id", e.id).put("content", r))
                    _ui.update { it.copy(lastResult = "${a.optString("action")}: $r") }
                }
                is AiEvent.Error -> say("نیٹ ورک میں مسئلہ ہے")
                is AiEvent.Done -> {}
            }
        }
        if (spoken.isNotBlank()) voice.speak(spoken.toString().trim())
        if (buf.isNotEmpty()) assistant.put(0, JSONObject().put("type", "text").put("text", buf.toString()))
        if (assistant.length() > 0) convo.put(JSONObject().put("role", "assistant").put("content", assistant))
        if (results.length() > 0) {
            convo.put(JSONObject().put("role", "user").put("content", results))
            if (confirmNeeded != null) {            // ask by voice, then listen for yes/no
                pendingConfirm = confirmNeeded
                voice.speak(exec.describe(confirmNeeded!!), true)
                voice.whenIdle { startListening() }
            } else if (depth < 6) runAiTurn(userText, depth + 1)   // let Claude see results & continue
        }
        _ui.update { it.copy(thinking = false) }
        dao.add(HistoryItem(command = userText, result = buf.toString().take(200)))
        // keep context small; always start on a plain user text turn so tool_use/tool_result pairs stay intact
        while (convo.length() > 24 || (convo.length() > 0 && convo.getJSONObject(0).opt("content") !is String)) {
            if (convo.length() <= 2) break
            convo.remove(0)
        }
    }

    private suspend fun done(cmd: String, result: String, reply: String) {
        voice.speak(reply, true)
        _ui.update { it.copy(lastResult = result, reply = reply, thinking = false) }
        dao.add(HistoryItem(command = cmd, result = result))
    }
    private fun say(t: String) { voice.speak(t, true); _ui.update { it.copy(reply = t, thinking = false) } }
    fun clearHistory() = viewModelScope.launch { dao.clear() }
    override fun onCleared() { voice.release() }
}
