package com.voicemaster.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/** STT + TTS. SpeechRecognizer must be used from the main thread. */
@Singleton
class VoiceEngine @Inject constructor(@ApplicationContext private val ctx: Context) {
    private var recognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private var onSpeakDone: (() -> Unit)? = null
    private var pending = 0

    // Lazy: TTS engine is created on first use, not at cold start.
    private val tts: TextToSpeech by lazy {
        TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = true
                val ur = tts.setLanguage(Locale("ur", "PK"))
                if (ur < TextToSpeech.LANG_AVAILABLE) tts.setLanguage(Locale("hi", "IN")) // fallback voice
                tts.setSpeechRate(1.05f)
            }
        }.also {
            it.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) { finishOne() }
                override fun onDone(id: String?) { finishOne() }
            })
        }
    }
    private fun finishOne() { pending = (pending - 1).coerceAtLeast(0); if (pending == 0) onSpeakDone?.invoke() }

    fun warmUp() { tts }

    /** Queue a sentence (does not interrupt the previous one) so speech starts while AI still streams. */
    fun speak(text: String, flush: Boolean = false) {
        if (text.isBlank()) return
        tts.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "u${System.nanoTime()}")
        if (flush) pending = 0
        pending++
    }
    fun stopSpeaking() { tts.stop(); pending = 0 }
    fun whenIdle(cb: () -> Unit) { if (pending == 0) cb() else onSpeakDone = { onSpeakDone = null; cb() } }

    fun listen(
        lang: String, onPartial: (String) -> Unit, onFinal: (String) -> Unit,
        onError: (Int) -> Unit, onRms: (Float) -> Unit = {}
    ) {
        stopSpeaking()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) onError(SpeechRecognizer.ERROR_NO_MATCH) else onFinal(t)
                }
                override fun onPartialResults(p: Bundle?) {
                    p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
                }
                override fun onError(e: Int) = onError(e)
                override fun onRmsChanged(v: Float) = onRms(v)
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true) // low latency when model is installed
        }
        recognizer?.startListening(i)
    }
    fun stopListening() { recognizer?.cancel() }
    fun release() { recognizer?.destroy(); recognizer = null; if (ttsReady) tts.shutdown() }
}
