package com.voicemaster.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** API key + simple settings. Encrypted prefs are created lazily (off the cold-start path). */
@Singleton
class SecureStore @Inject constructor(@ApplicationContext private val ctx: Context) {
    private val prefs by lazy {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "vm_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) = prefs.edit().putString("api_key", v.trim()).apply()
    /** Speech recognition language tag: hi-IN handles Hindi + Hinglish; en-IN for English. */
    var sttLang: String
        get() = prefs.getString("stt_lang", "hi-IN") ?: "hi-IN"
        set(v) = prefs.edit().putString("stt_lang", v).apply()
    var wakeWord: Boolean
        get() = prefs.getBoolean("wake", false)
        set(v) = prefs.edit().putBoolean("wake", v).apply()
}
