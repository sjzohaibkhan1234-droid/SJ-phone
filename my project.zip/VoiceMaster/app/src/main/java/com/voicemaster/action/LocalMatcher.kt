package com.voicemaster.action

import org.json.JSONObject

/** Instant, no-AI matching for the most common commands (Hindi / English / Hinglish). */
object LocalMatcher {
    private val openRx = Regex("""^(?:open|launch|start|kholo|khol do|khol|chalu karo|खोलो|खोल दो|ओपन)\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val openRx2 = Regex("""^(.+?)\s+(?:open karo|kholo|khol do|खोलो|ओपन करो|चालू करो)$""", RegexOption.IGNORE_CASE)
    private val alarmRx = Regex("""(?:alarm|अलार्म).*?(\d{1,2})(?::|\s)?(\d{2})?""", RegexOption.IGNORE_CASE)
    private val timerRx = Regex("""(\d+)\s*(minute|min|मिनट|second|sec|सेकंड|घंटे|hour)""", RegexOption.IGNORE_CASE)

    class Result(val action: String, val args: JSONObject, val reply: String)

    fun match(raw: String): Result? {
        val t = raw.trim().lowercase()
        val torchOn = listOf("torch on", "flashlight on", "टॉर्च चालू", "torch jalao", "flashlight chalu", "light on")
        val torchOff = listOf("torch off", "flashlight off", "टॉर्च बंद", "torch band", "flashlight band")
        if (torchOn.any { t.contains(it) }) return r("flashlight", "state" to "on", reply = "ٹارچ آن ہو گئی")
        if (torchOff.any { t.contains(it) }) return r("flashlight", "state" to "off", reply = "ٹارچ بند ہو گئی")
        if (Regex("volume (up|badhao|zyada)|आवाज़? बढ़ा|वॉल्यूम बढ़ा").containsMatchIn(t)) return r("volume", "state" to "up", reply = "آواز بڑھا دی")
        if (Regex("volume (down|kam)|आवाज़? कम|वॉल्यूम कम").containsMatchIn(t)) return r("volume", "state" to "down", reply = "آواز کم کر دی")
        if (Regex("\\bmute\\b|म्यूट|silent").containsMatchIn(t)) return r("volume", "state" to "mute", reply = "آواز بند کر دی")
        if (t.contains("screenshot") || t.contains("स्क्रीनशॉट")) return r("screenshot", reply = "اسکرین شاٹ لے لیا")
        if (t == "back" || t == "पीछे जाओ" || t == "wapas jao") return r("press", "key" to "back", reply = "ٹھیک ہے")
        if (t == "home" || t == "होम") return r("press", "key" to "home", reply = "ٹھیک ہے")
        timerRx.find(t)?.let { m ->
            if (t.contains("timer") || t.contains("टाइमर")) {
                val n = m.groupValues[1].toInt(); val u = m.groupValues[2]
                val secs = when { u.startsWith("sec") || u == "सेकंड" -> n; u.startsWith("h") || u == "घंटे" -> n * 3600; else -> n * 60 }
                return r("set_timer", "seconds" to secs, reply = "ٹائمر لگا دیا")
            }
        }
        if (t.contains("alarm") || t.contains("अलार्म")) alarmRx.find(t)?.let { m ->
            var h = m.groupValues[1].toInt(); val mi = m.groupValues[2].ifBlank { "0" }.toInt()
            if (Regex("\\bpm\\b|शाम|रात").containsMatchIn(t) && h < 12) h += 12
            if (h in 0..23 && mi in 0..59) return r("set_alarm", "hour" to h, "minute" to mi, reply = "الارم لگا دیا")
        }
        (openRx.find(t) ?: openRx2.find(t))?.let { return r("open_app", "app" to it.groupValues[1].trim(), reply = "کھول رہا ہوں") }
        return null // → send to Claude
    }

    private fun r(a: String, vararg kv: Pair<String, Any>, reply: String) =
        Result(a, JSONObject().put("action", a).also { j -> kv.forEach { j.put(it.first, it.second) } }, reply)
}
