package com.voicemaster.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageButton
import androidx.core.app.NotificationCompat
import com.voicemaster.ui.MainActivity

/**
 * Lightweight foreground service: keeps the process alive (START_STICKY) and shows a floating mic
 * button. Tapping it opens the assistant, which starts listening. Kill switch = notification action.
 */
class AssistantService : Service() {
    private var wm: WindowManager? = null
    private var btn: ImageButton? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vm", "VoiceMaster", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, AssistantService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "vm").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("VoiceMaster is active").setOngoing(true)
            .addAction(0, "STOP", stop).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        showBubble()
        return START_STICKY
    }

    private fun showBubble() {
        if (btn != null || !Settings.canDrawOverlays(this)) return
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        btn = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now); setBackgroundResource(android.R.drawable.btn_default_small)
            setOnClickListener {
                startActivity(Intent(this@AssistantService, MainActivity::class.java)
                    .putExtra("autolisten", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            }
        }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm?.addView(btn, lp)
    }

    override fun onDestroy() { btn?.let { wm?.removeView(it) }; btn = null; super.onDestroy() }
}
