package com.voicemaster.ai

import org.json.JSONArray
import org.json.JSONObject

object Prompts {
    const val SYSTEM = """You are VoiceMaster, a voice assistant that controls the user's Android phone.
The user speaks Hindi, English or Hinglish. ALWAYS reply to the user in Urdu (Urdu script), in short natural spoken sentences (max 2 sentences). No markdown, no emojis, no lists - your text is read aloud.
When the user wants something done, call the `phone_action` tool. You may call it several times in order for multi-step tasks. For screen tasks: call read_screen first, then tap_text / tap / type_text / scroll, and read_screen again to verify.
Rules:
- Never invent contact names or numbers. If a contact is ambiguous, ask a short question instead of acting.
- Calls, SMS and anything involving money are confirmed by the app before running; just request them.
- Never operate banking, payment, password or OTP screens. If the screen looks like one, stop and tell the user.
- If a request is impossible on Android, say so briefly and offer the closest alternative.
- For plain questions, answer briefly without tools."""

    val ACTIONS = listOf(
        "open_app", "call_contact", "send_sms", "set_alarm", "set_timer", "flashlight",
        "volume", "brightness", "wifi_panel", "bluetooth_panel", "open_url", "web_search",
        "play_music", "read_notifications", "read_screen", "tap_text", "tap", "scroll",
        "type_text", "press", "screenshot"
    )

    fun tools(): JSONArray = JSONArray().put(JSONObject("""{
      "name": "phone_action",
      "description": "Perform one action on the user's phone.",
      "input_schema": {
        "type": "object",
        "properties": {
          "action": {"type": "string", "enum": ${JSONArray(ACTIONS)}},
          "app": {"type": "string", "description": "App name for open_app, e.g. WhatsApp"},
          "contact": {"type": "string", "description": "Contact name for call_contact/send_sms"},
          "number": {"type": "string", "description": "Phone number if given by user"},
          "message": {"type": "string", "description": "SMS body or alarm label"},
          "hour": {"type": "integer"}, "minute": {"type": "integer"}, "seconds": {"type": "integer"},
          "state": {"type": "string", "enum": ["on","off","up","down","max","min","mute"]},
          "level": {"type": "integer", "description": "0-100 for brightness/volume"},
          "query": {"type": "string", "description": "Search text, song, or URL"},
          "text": {"type": "string", "description": "Text to tap or type"},
          "x": {"type": "integer"}, "y": {"type": "integer"},
          "direction": {"type": "string", "enum": ["up","down","left","right"]},
          "key": {"type": "string", "enum": ["back","home","recents","notifications","quick_settings","lock"]}
        },
        "required": ["action"]
      }
    }"""))
}
