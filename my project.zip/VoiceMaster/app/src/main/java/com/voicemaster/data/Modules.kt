package com.voicemaster.data

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module @InstallIn(SingletonComponent::class)
object Modules {
    @Provides @Singleton fun db(@ApplicationContext c: Context) = AppDb.build(c)
    @Provides fun historyDao(db: AppDb) = db.history()
}
