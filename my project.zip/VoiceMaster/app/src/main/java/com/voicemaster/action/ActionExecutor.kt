package com.voicemaster.action

import android.Manifest
import android.annotation.SuppressLint
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.voicemaster.service.AssistantAccessibilityService as A11y
import com.voicemaster.service.NotifListener
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ActionExecutor @Inject constructor(@ApplicationContext private val ctx: Context) {

    /** Actions that must be confirmed by voice first. */
    fun needsConfirm(action: String) = action == "call_contact" || action == "send_sms"

    fun describe(a: JSONObject): String = when (a.optString("action")) {
        "call_contact" -> "کیا میں ${a.optString("contact", a.optString("number"))} کو کال کروں؟"
        "send_sms" -> "کیا میں ${a.optString("contact", a.optString("number"))} کو یہ پیغام بھیج دوں: ${a.optString("message")}؟"
        else -> "کیا میں یہ کر دوں؟"
    }

    // ---- app cache (built once, off main thread) ----
    private val apps: Map<String, String> by lazy {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(i, 0).associate { it.loadLabel(pm).toString().lowercase() to it.activityInfo.packageName }
    }
    private val aliases = mapOf("whatsapp" to "whatsapp", "व्हाट्सएप" to "whatsapp", "यूट्यूब" to "youtube",
        "कैमरा" to "camera", "सेटिंग्स" to "settings", "क्रोम" to "chrome", "गैलरी" to "gallery", "फोन" to "phone")

    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    private fun start(i: Intent): Boolean = try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (_: Exception) { false }

    suspend fun execute(a: JSONObject): String = withContext(Dispatchers.IO) {
        try { run(a) } catch (t: SecurityException) { "اجازت درکار ہے" } catch (t: Throwable) { "ناکام: ${t.message}" }
    }

    @SuppressLint("MissingPermission")
    private fun run(a: JSONObject): String {
        val s = A11y.instance
        return when (a.getString("action")) {
            "open_app" -> {
                val q = a.optString("app").lowercase().let { aliases[it] ?: it }
                val pkg = apps[q] ?: apps.entries.firstOrNull { it.key.contains(q) || q.contains(it.key) }?.value
                val li = pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) }
                if (li != null && start(li)) "opened ${a.optString("app")}" else "app not found"
            }
            "call_contact" -> {
                if (!has(Manifest.permission.CALL_PHONE)) return "need CALL_PHONE permission"
                val n = number(a) ?: return "contact not found"
                if (start(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n")))) "calling $n" else "call failed"
            }
            "send_sms" -> {
                if (!has(Manifest.permission.SEND_SMS)) return "need SEND_SMS permission"
                val n = number(a) ?: return "contact not found"
                val sm = ctx.getSystemService(SmsManager::class.java)
                sm.sendMultipartTextMessage(n, null, sm.divideMessage(a.optString("message")), null, null); "sms sent to $n"
            }
            "set_alarm" -> start(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("message")).putExtra(AlarmClock.EXTRA_SKIP_UI, true)).let { if (it) "alarm set" else "alarm failed" }
            "set_timer" -> start(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds")).putExtra(AlarmClock.EXTRA_SKIP_UI, true)).let { if (it) "timer set" else "timer failed" }
            "flashlight" -> {
                val cm = ctx.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                val on = a.optString("state") != "off"; cm.setTorchMode(id, on); "torch ${if (on) "on" else "off"}"
            }
            "volume" -> {
                val am = ctx.getSystemService(AudioManager::class.java); val st = AudioManager.STREAM_MUSIC
                val max = am.getStreamMaxVolume(st)
                when (a.optString("state")) {
                    "up" -> am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    "down" -> am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    "mute" -> am.setStreamVolume(st, 0, AudioManager.FLAG_SHOW_UI)
                    "max" -> am.setStreamVolume(st, max, AudioManager.FLAG_SHOW_UI)
                    "min" -> am.setStreamVolume(st, 1, AudioManager.FLAG_SHOW_UI)
                    else -> if (a.has("level")) am.setStreamVolume(st, a.getInt("level") * max / 100, AudioManager.FLAG_SHOW_UI)
                }; "volume changed"
            }
            "brightness" -> {
                if (!Settings.System.canWrite(ctx)) { start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))); return "grant Modify system settings first" }
                val lvl = (a.optInt("level", if (a.optString("state") == "down") 30 else 80) * 255 / 100)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, lvl); "brightness set"
            }
            // Android blocks silent Wi-Fi/Bluetooth toggling (API 29+); open the system panel instead.
            "wifi_panel" -> { start(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)); "wifi panel opened - tap to toggle" }
            "bluetooth_panel" -> { start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "bluetooth settings opened" }
            "open_url" -> if (start(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("query"))))) "opened" else "failed"
            "web_search" -> if (start(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, a.getString("query")))) "searching" else "failed"
            "play_music" -> if (start(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(SearchManager.QUERY, a.optString("query")).putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*"))) "playing" else "no music app"
            "read_notifications" -> NotifListener.recent().ifEmpty { "no notifications or access not granted" }
            "read_screen" -> s?.readScreen() ?: "accessibility service is off"
            "tap_text" -> s?.tapText(a.getString("text")) ?: "accessibility service is off"
            "tap" -> s?.tap(a.getInt("x").toFloat(), a.getInt("y").toFloat()) ?: "accessibility service is off"
            "scroll" -> s?.scroll(a.optString("direction", "down")) ?: "accessibility service is off"
            "type_text" -> s?.typeText(a.getString("text")) ?: "accessibility service is off"
            "press" -> s?.press(a.getString("key")) ?: "accessibility service is off"
            "screenshot" -> s?.press("screenshot") ?: "accessibility service is off"
            else -> "unknown action"
        }
    }

    private fun number(a: JSONObject): String? {
        a.optString("number").takeIf { it.isNotBlank() }?.let { return it }
        val name = a.optString("contact").takeIf { it.isNotBlank() } ?: return null
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }
}
