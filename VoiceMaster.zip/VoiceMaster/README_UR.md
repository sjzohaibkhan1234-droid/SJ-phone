# VoiceMaster: PC کے بغیر APK بنانا
1. فون کے براؤزر میں github.com پر مفت اکاؤنٹ بنائیں۔
2. نیا Repository بنائیں اور اس zip کی تمام فائلیں Upload کریں (.github فولڈر سمیت)۔
3. Actions ٹیب ← "Build APK" ← Run workflow۔ چند منٹ بعد Artifacts سے APK ڈاؤن لوڈ کریں۔
4. APK انسٹال کریں، ایپ کھولیں، "Accessibility آن کریں" دبائیں اور VoiceMaster آن کریں۔
5. ایپ میں Claude API Key اور اپنی Video API کا URL ڈالیں۔
