package com.voicemaster
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); Guard.load(this)
        setContent { MaterialTheme { Screen() } }
    }
    @Composable fun Screen() {
        var on by remember { mutableStateOf(Guard.active) }
        var cmd by remember { mutableStateOf("") }
        var key by remember { mutableStateOf(Guard.key(this)) }
        var vurl by remember { mutableStateOf(Guard.videoUrl(this)) }
        var out by remember { mutableStateOf("") }
        val scope = rememberCoroutineScope()
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("VoiceMaster", style = MaterialTheme.typography.headlineMedium)
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(if (on) "Active: رسائی آن" else "Off: رسائی بند", Modifier.weight(1f))
                Switch(on, { on = it; Guard.set(this@MainActivity, it) })
            }
            Button({ startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Accessibility آن کریں (ایک بار)") }
            OutlinedTextField(cmd, { cmd = it }, label = { Text("کمانڈ: Claude کھولو / TikTok / Play") }, modifier = Modifier.fillMaxWidth())
            Button({
                val app = Launcher.parse(cmd)
                out = if (app != null) { if (Launcher.open(this@MainActivity, app)) "کھل گیا" else "Active آن کریں" }
                      else "صرف Claude, Google Play, TikTok"
            }) { Text("چلاؤ") }
            OutlinedTextField(key, { key = it; Guard.saveKey(this@MainActivity, it) }, label = { Text("Claude API Key") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(vurl, { vurl = it; Guard.saveVideoUrl(this@MainActivity, it) }, label = { Text("Video API URL") }, modifier = Modifier.fillMaxWidth())
            Button({
                if (!on) { out = "پہلے Active آن کریں"; return@Button }
                scope.launch {
                    out = "اسکرپٹ بن رہی ہے..."
                    val s = Api.script(key, cmd.ifBlank { "interesting fact" })
                    out = "ویڈیو بن رہی ہے...\n" + s
                    out = Api.video(vurl, s).take(500)
                    Launcher.open(this@MainActivity, "tiktok")
                }
            }) { Text("AI ویڈیو بناؤ → TikTok") }
            Text(out)
        }
    }
}
