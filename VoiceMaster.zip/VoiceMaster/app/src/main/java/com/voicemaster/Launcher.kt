package com.voicemaster
import android.content.Context
import android.content.Intent

object Launcher {
    fun open(c: Context, name: String): Boolean {
        if (!Guard.active) return false
        for (pkg in Guard.allowed[name] ?: return false) {
            val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: continue
            c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
        }
        return false
    }
    // نام پہچاننا: اردو، ہندی، انگریزی
    fun parse(t: String): String? {
        val s = t.lowercase()
        return when {
            listOf("claude", "کلاؤڈ", "क्लाउड").any { s.contains(it) } -> "claude"
            listOf("play", "پلے", "प्ले", "गूगल प्ले").any { s.contains(it) } -> "play"
            listOf("tiktok", "tik tok", "ٹک ٹاک", "टिकटॉक").any { s.contains(it) } -> "tiktok"
            else -> null
        }
    }
}
