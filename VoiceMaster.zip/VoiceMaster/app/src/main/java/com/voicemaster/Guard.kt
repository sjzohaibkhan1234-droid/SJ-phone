package com.voicemaster
import android.content.Context

object Guard {
    // صرف یہی تین ایپس
    val allowed = mapOf(
        "claude" to listOf("com.anthropic.claude"),
        "play" to listOf("com.android.vending"),
        "tiktok" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
    )
    @Volatile var active = false
    private fun p(c: Context) = c.getSharedPreferences("vm", Context.MODE_PRIVATE)
    fun load(c: Context) { active = p(c).getBoolean("active", false) }
    fun set(c: Context, v: Boolean) { active = v; p(c).edit().putBoolean("active", v).apply() }
    fun key(c: Context) = p(c).getString("key", "") ?: ""
    fun saveKey(c: Context, k: String) = p(c).edit().putString("key", k).apply()
    fun videoUrl(c: Context) = p(c).getString("vurl", "") ?: ""
    fun saveVideoUrl(c: Context, u: String) = p(c).edit().putString("vurl", u).apply()
}
