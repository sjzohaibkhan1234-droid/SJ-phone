package com.voicemaster
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    // Claude سے ویڈیو اسکرپٹ (پرامپٹ انگریزی میں)
    suspend fun script(key: String, topic: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("model", "claude-sonnet-5-5").put("max_tokens", 600)
            .put("messages", JSONArray().put(JSONObject().put("role", "user")
                .put("content", "Write a short 20-second TikTok video script and a visual prompt about: $topic")))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val txt = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode >= 400) return@withContext "خرابی: $txt"
        JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
    }
    // آپ کی ویڈیو API: URL سیٹنگ میں ڈالیں۔ فارمت آپ کی سروس کے مطابق بدلیں۔
    suspend fun video(url: String, prompt: String): String = withContext(Dispatchers.IO) {
        if (url.isBlank()) return@withContext "ویڈیو API کا URL ڈالیں"
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(JSONObject().put("prompt", prompt).toString().toByteArray()) }
        (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
    }
}
