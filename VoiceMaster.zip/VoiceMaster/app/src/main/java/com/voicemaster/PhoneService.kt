package com.voicemaster
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PhoneService : AccessibilityService() {
    override fun onServiceConnected() { Guard.load(this); inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}  // غیر فعال: کچھ نہیں دیکھتا
    override fun onInterrupt() {}
    override fun onDestroy() { inst = null; super.onDestroy() }

    private fun root(): AccessibilityNodeInfo? {
        val r = rootInActiveWindow ?: return null
        val pkg = r.packageName?.toString() ?: return null
        return if (Guard.active && Guard.allowed.values.flatten().contains(pkg)) r else null
    }
    fun tapText(t: String): Boolean {
        val n = root()?.findAccessibilityNodeInfosByText(t)?.firstOrNull() ?: return false
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }
    fun scroll(): Boolean = root()?.let { r -> find(r)?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) } ?: false
    private fun find(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { find(it)?.let { f -> return f } }
        return null
    }
    companion object { var inst: PhoneService? = null }
}
